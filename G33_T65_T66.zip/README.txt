Demo Video:
https://youtu.be/hP7_zW_NAT8

These are the scripts that were used to carry out the project.
Since the dataset is more than 100GB, we can not upload it.
Please contact any one of us if you want to run the code, we will give you the link to our IPython Notebooks.

Shreekantha Nadig MS2016010 shreekantha.nadig@iiitb.org
Vaishnav MS2016006
Amit Kumar MT2016009
